#!/bin/bash

./tpa-1.1 -t 5 /dev/stdin | head -n1
