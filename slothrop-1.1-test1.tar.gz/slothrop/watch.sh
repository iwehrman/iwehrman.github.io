#!/bin/bash
tail -f $1 | grep "Back\|Close\|Open\|Check\|Size\|Cost\|Proceed\|Orient\|COMPLETION"