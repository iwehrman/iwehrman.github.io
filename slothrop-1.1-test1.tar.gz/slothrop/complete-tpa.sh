#!/bin/bash
./slothrop --complete --tpa --cmd "./run-tpa.sh" $*
