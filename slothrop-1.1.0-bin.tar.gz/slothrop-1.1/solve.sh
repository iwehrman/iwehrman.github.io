#!/bin/bash
./slothrop --aprove --cmd "./run-aprove.sh" $*