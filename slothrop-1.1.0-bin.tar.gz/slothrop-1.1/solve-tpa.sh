#!/bin/bash
./slothrop --tpa --cmd "./run-tpa.sh" $*
