#!/bin/bash
cd ~/local/AProVE/
java -Xmx500m -jar AProVE.jar -u bat -e trs -m bool -t 5
