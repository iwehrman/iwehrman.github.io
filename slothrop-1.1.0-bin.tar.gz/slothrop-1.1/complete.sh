#!/bin/bash
./slothrop --complete --aprove --cmd "./run-aprove.sh" $*